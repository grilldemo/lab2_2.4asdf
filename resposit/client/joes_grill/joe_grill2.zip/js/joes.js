var item_name;
var item_price;
var item_calorie;
var item_rating;
var item_purchesed;