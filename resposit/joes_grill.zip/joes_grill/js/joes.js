var order_id;
var order_item_id;
var item_id;
var item_quantity;
var card_num;
var address;